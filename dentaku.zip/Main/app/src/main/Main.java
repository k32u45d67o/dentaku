package main;

import java.awt.FlowLayout;
import java.awt.BorderLayout;

import javax.swing.JFrame;

public class Main {

	public static void main(String args[]) {
		Frame frame = new Frame();
		frame.setLayout(new BorderLayout());
		frame.setSize(400, 450);
		frame.addMyComponent();
		frame.setVisible(true);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		System.out.println("google pixel5a is nice");
	}

}