package main;

import java.awt.GridLayout;
import javax.swing.JFrame;
import component.MyTextField;
import component.MyButton;

public class Frame extends JFrame{

	MyButton button;
	MyTextField textfield;
	public Frame() {
		textfield = new MyTextField();
		button = new MyButton(textfield);
	}
	
	public void addMyComponent() {
		textfield.setMyComponent();
		button.mysetComponent();
		add("North",textfield);
		add("Center",button);
	}
	
}