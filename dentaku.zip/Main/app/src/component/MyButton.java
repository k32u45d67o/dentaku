package component;


import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JPanel;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.FileWriter;
import java.io.BufferedWriter;
import java.io.FileWriter;
	
import java.io.IOException;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import component.button.KigouButton;
import component.button.DelStrategy;
import component.button.AcStrategy;

public class MyButton extends JPanel {

	MyTextField textfield;
	
	AButton b0;
	AButton b1;
	AButton b2;
	AButton b3;
	AButton b4;
	AButton b5;
	AButton b6;
	AButton b7;
	AButton b8;
	AButton b9;
	
	KigouButton bDEL;
	KigouButton bAC;
	
	
	MyButton_hoge bhoge;
	MyButton_kakeru bkakeru;
	MyButton_tasu btasu;
	MyButton_waru bwaru;
	MyButton_hiku bhiku;
	MyButton_ikoru bikoru;
	MyButton_Ans bans;
	
	public MyButton(MyTextField textfield) {
		this.textfield = textfield;
		b0 = new AButton("0");
		b1 = new AButton("1");
		b2 = new AButton("2");
		b3 = new AButton("3");
		b4 = new AButton("4");
		b5 = new AButton("5");
		b6 = new AButton("6");
		b7 = new AButton("7");
		b8 = new AButton("8");
		b9 = new AButton("9");
		
		bDEL = new KigouButton(new DelStrategy(),textfield,"DEL");
		bAC = new KigouButton(new AcStrategy(), textfield,"AC");
		
		bhoge = new MyButton_hoge();
		bkakeru = new MyButton_kakeru();
		btasu = new MyButton_tasu();
		bwaru = new MyButton_waru();
		bhiku = new MyButton_hiku();
		bikoru = new MyButton_ikoru();
		bans = new MyButton_Ans();
	}
	
	public void mysetComponent() {
		setLayout(new GridLayout(4,5));
		
		b0.mysetText();
		b1.mysetText();
		b2.mysetText();
		b3.mysetText();
		b4.mysetText();
		b5.mysetText();
		b6.mysetText();
		b7.mysetText();
		b8.mysetText();
		b9.mysetText();
		bDEL.mysetText();
		bAC.mysetText();
		bhoge.mysetText();
		bkakeru.mysetText();
		btasu.mysetText();
		bwaru.mysetText();
		bhiku.mysetText();
		bikoru.mysetText();
		bans.mysetText();
		
		add(b7);
		add(b8);
		add(b9);
		add(bDEL);
		add(bAC);
		add(b4);
		add(b5);
		add(b6);
		add(bkakeru);
		add(bwaru);
		add(b1);
		add(b2);
		add(b3);
		add(btasu);
		add(bhiku);
		add(b0);
		add(bhoge);
		add(bhoge);
		add(bans);
		add(bikoru);
	}
	
	
	
	public class AButton extends JButton{
		String s;
		public AButton(String s) {
			this.s = s;
			addActionListener(new MyActionListener());
		}
			
		
		public void mysetText() {
			setText(s);
		}
		
		public class MyActionListener implements ActionListener {

			public void actionPerformed(ActionEvent e) {
				System.out.println(s);
				textfield.myaddSikiText(s);
			}
		}
	}
	

	public class MyButton_kakeru extends JButton  {	

		public MyButton_kakeru() {
			addActionListener(new MyActionListener());
		}
		
		public class MyActionListener implements ActionListener {

			public void actionPerformed(ActionEvent e) {
				textfield.myaddSikiText("x");
			}
		}

		public void mysetText() {
			setText("x");
		}		
	}
	
	public class MyButton_waru extends JButton {
		public MyButton_waru() {
			addActionListener(new MyActionListener());			
		
		}
		
		public class MyActionListener implements ActionListener {

			public void actionPerformed(ActionEvent e) {
				textfield.myaddSikiText("/");
			}
		}		
		
		public void mysetText() {
			setText("/");
		}

	}
	
	
	public class MyButton_tasu extends JButton{

		public MyButton_tasu() {
			addActionListener(new MyActionListener());	
		
		}
		
		public class MyActionListener implements ActionListener {

			public void actionPerformed(ActionEvent e) {
				textfield.myaddSikiText("+");
			}
		}
		
		public void mysetText() {
			setText("+");
		}
	}
	
	public class MyButton_hiku extends JButton {

		public MyButton_hiku() {
			addActionListener(new MyActionListener());	
		
		}		
		
		public class MyActionListener implements ActionListener {

			public void actionPerformed(ActionEvent e) {
				textfield.myaddSikiText("-");
			}			
		}
		public void mysetText() {
			setText("-");
		}
	
	}
	
	public class MyButton_ikoru extends JButton {
		
		public MyButton_ikoru() {
			addActionListener(new MyActionListener());	
		
		}
		
		public class MyActionListener implements ActionListener{
	
			public void actionPerformed(ActionEvent e) {
				textfield.mysetAnsText( String.valueOf(textfield.ikoru()));
			}
		}
		public void mysetText() {
			setText("=");
		}
	}	
	
	public class MyButton_Ans extends JButton  {
	
		public MyButton_Ans() {
			addActionListener(new MyActionListener());	
		
		}	
		public class MyActionListener implements ActionListener{
	
			public void actionPerformed(ActionEvent e) {
				textfield.myaddSikiText("Ans");
			}
		}
		public void mysetText() {
			setText("Ans");
		}
	}
	
	public class MyButton_hoge extends JButton{
		public MyButton_hoge() {
		}
		
		public class MyActionListener implements ActionListener{
	
			public void actionPerformed(ActionEvent e) {
				textfield.myaddSikiText("hoge");
			}
		}
		public void mysetText() {
			setText("hoge");
		}
	}	
	
	public static class InputDate {
		public static String filepass_siki = "C:/mainwork/program/dentaku/ver1/date/siki.txt";
		public static String filepass_ans = "C:/mainwork/program/dentaku/ver1/date/ans.txt";
		private static FileWriter filewriter;
		private static BufferedWriter bufferedwriter; 
		private static ArrayList<Integer> list = new ArrayList<>();

		public static void in(String s) {
			try {
				filewriter= new FileWriter(filepass_siki);
				bufferedwriter = new BufferedWriter(filewriter);
				bufferedwriter.write(s);
			}catch(IOException e) {
				e.printStackTrace();
			}
		}	
		
	}
	
	public static class OutputDate {
		public static final String filepass_siki = "C:/mainwork/program/dentaku/ver1/date/siki.txt";
		public static final String filepass_ans = "C:/mainwork/program/dentaku/ver1/date/ans.txt";
		private static FileReader filereader;
		private static BufferedReader bufferedreader;
		
		private ArrayList<Integer> list = new ArrayList<>();
		public static String out() {
			String s = null;
			try {
				filereader = new FileReader(filepass_siki);
				bufferedreader = new BufferedReader(filereader);
				s = bufferedreader.readLine();
			}catch(IOException e) {
				e.printStackTrace();
			}
			return s;
		}
	}
	
}