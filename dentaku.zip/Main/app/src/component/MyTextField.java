package component;

import java.awt.TextField;
import java.awt.GridLayout;
import javax.swing.JPanel;
import java.io.FileWriter;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.PrintWriter;

import java.io.File;

import date.SikiIndex;

public class MyTextField extends JPanel {
	
	Answer answer;
	Siki siki;
	
	File file;
	FileWriter filewriter = null;
	PrintWriter out;
	BufferedWriter bufferedwriter;
	
	StringBuilder buffes = new StringBuilder();
	
	public MyTextField() {
		answer = new Answer();
		siki = new Siki();
	}
	
	
	public void setMyComponent() {
		setLayout(new GridLayout(2,1));
		add(siki);
		add(answer);
	}
	
	public void myaddSikiText(String s){
		buffes.append(s);
		siki.setText(buffes.toString());
		System.out.println(buffes.toString());

	}
	
	public void mysetAnsText(String s) {
		answer.setText(s);
	}
	
	public void del() {
		
		buffes.setLength(0);	
		siki.setText(buffes.toString());
	}
	
	public double ikoru()  {
		double ans =0;
		int indexoftasu = buffes.indexOf("+");
		int indexofhiku = buffes.indexOf("-");
		int indexofkakeru = buffes.indexOf("x");
		int indexofwaru = buffes.indexOf("/");
		if(indexoftasu != -1) {
			ans =  Integer.parseInt(buffes.substring(0,indexoftasu)) +  Integer.parseInt(buffes.substring(indexoftasu+1));
		}
		if(indexofhiku !=-1) {
			ans = Integer.parseInt(buffes.substring(0,indexofhiku)) - Integer.parseInt(buffes.substring(indexofhiku+1));
			
		}
		if(indexofwaru != -1) {
			ans = Integer.parseInt(buffes.substring(0,indexofwaru)) / Integer.parseInt(buffes.substring(indexofwaru + 1));
		}
		if(indexofkakeru != -1) {
			ans = Integer.parseInt(buffes.substring(0,indexofkakeru)) * Integer.parseInt(buffes.substring(indexofkakeru + 1));
		}
		return ans;
		
	}

	
	public class Answer extends TextField {
	
		public Answer() {
			
		}
	
	}
	
	public class Siki extends TextField {
	
		public Siki() {
		}
	
	}
}