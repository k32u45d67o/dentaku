package component.button;

import component.MyTextField;

public class DelStrategy implements Strategy {
		
	public DelStrategy() {
	}
	
	public void index(MyTextField textfield) {
		System.out.println("DelStrategy");
		textfield.del();
	}
}
	