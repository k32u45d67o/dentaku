package component.button;
import component.MyTextField;

public class AcStrategy implements Strategy{

	public AcStrategy() {
	}
	
	public void index(MyTextField textfield) {
		System.out.println("AcStrategy");
		textfield.del();
	}
}