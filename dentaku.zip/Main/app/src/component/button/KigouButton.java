package component.button;

import javax.swing.JButton;

import component.MyTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


public class KigouButton extends JButton {

	private Strategy strategy;
	MyTextField textfield;
	String s;
	public KigouButton(Strategy strategy,MyTextField textfield, String s) {
		this.strategy = strategy;
		this.textfield = textfield;
		this.s = s;
		addActionListener(new MyActionListener());
	}
	
	public void mysetText() {
		setText(s);
	}	
	
	public class MyActionListener implements ActionListener {

		public void actionPerformed(ActionEvent e) {
			strategy.index(textfield);
		}
		
	}
}