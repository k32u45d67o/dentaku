package component.button;

import component.MyTextField;

public interface Strategy {

	public abstract void index(MyTextField textfield);

}