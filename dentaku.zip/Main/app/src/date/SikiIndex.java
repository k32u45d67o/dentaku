package date;

import java.util.ArrayList;

public class SikiIndex {

	public static ArrayList<String> s = new ArrayList<>();
	
	public static void add(String str) {
		s.add(str);
	}
	
	public static ArrayList<String> getIndex() {
		return s;
	}
	
	public static int getsize() {
		return s.size();
	}

}